This directly contains scripts and tools adopted from other open source projects such as Apache Joshua and Moses Decoder.

TODO: credit the authors and resolve license issues (if any)
